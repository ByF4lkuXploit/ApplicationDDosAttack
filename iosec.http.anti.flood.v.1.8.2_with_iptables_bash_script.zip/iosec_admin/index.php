<?php
echo "Please restrict access to this folder. If you can view this file, something is wrong.";
?>